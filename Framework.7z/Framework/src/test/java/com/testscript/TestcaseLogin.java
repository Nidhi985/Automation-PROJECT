package com.testscript;


import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.Loginpage;
import com.testbase.Baseclass;
import com.utilities.Reusablecomponents;

public class TestcaseLogin extends Baseclass {
	Reusablecomponents reuse=new Reusablecomponents();
	Loginpage loginpage=new Loginpage();
	

	public TestcaseLogin() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	
  @Test(description="This is a Login Test")
 public void correctlogin() throws IOException {	
	
	
	// reuse.entertext(driver.findElement(By.xpath("//input[@id='username']")),prop.getProperty("Password"));
	//reuse.entertext(driver.findElement(By.xpath("//input[@id='password']")),prop.getProperty("Password"));
	  //reuse.entertext(loginpage.enterusername(),"nidhi");
	  loginpage.enterusername();
	 // reuse.entertext(loginpage.password(),prop.getProperty("Password"));
	// loginpage.clickaction().click();
	 
		
  }
 /* @Test(description="This is a Invalid Login Test")
  public void invalidlogin() {
	  	  
	  reuse.entertext(loginpage.username(),"s");
	  reuse.entertext(loginpage.password(),"98765");
	  loginpage.clickaction().click();
	  String Actual=reuse.getText(loginpage.gettingtext());
	  assertEquals(Actual,Expected );
	  waittime(10000);
	
	  }*/
  @BeforeMethod()
  public void beforeMethod() {
	 init();
	 launch();
	 windowmximize();
	 waittime(6000);
  }

 /* @AfterMethod
  public void afterMethod() {
	  driver.close();
  }*/

}
