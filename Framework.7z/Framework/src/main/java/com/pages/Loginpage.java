package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.FindBy;

import com.testbase.Baseclass;
import com.utilities.Reusablecomponents;

public class Loginpage extends Baseclass {
	Reusablecomponents reuse=new Reusablecomponents();
	/*public Loginpage() throws IOException {
		super();
		init();*/
		public Loginpage() throws IOException {
			PageFactory.initElements(driver, this);
		}

		
		@FindBy(xpath = "//input[@id='username']")
		WebElement username;
		@FindBy(xpath = "//input[@id='password']")
		WebElement password;
		// TODO Auto-generated constructor stub
	
	
	
	/*public Loginpage(WebDriver driver)
	{
		this.driver=driver;
	}*/

	//one way
	//By username=By.xpath("//input[@id='username']");
	/*WebElement username=driver.findElement(By.xpath("//input[@id='username']"));
	WebElement password=driver.findElement(By.xpath("//input[@id='password']"));
	WebElement clickaction=driver.findElement(By.xpath("//button[contains(text(),' Sign In')]"));
	//By clickaction=By.xpath("//button[contains(text(),' Sign In')]");
	WebElement text=driver.findElement(By.xpath("//span[contains(text(),'Bad credentials')]"));*/
		public void enterusername()
		{
			reuse.entertext(this.username,"Nidhi");
			//return this.username;
		}
		public  WebElement password()
		{
			return this.password;
		}
		}
/*	{
		return this.username;
		
	}
	//Another way
	
	public  WebElement password()
	{
		return this.password;
	}
	public WebElement clickaction()
	{
		return this.clickaction;
	}
	public WebElement gettingtext()
	{
		return text;
	}*/
	
	

