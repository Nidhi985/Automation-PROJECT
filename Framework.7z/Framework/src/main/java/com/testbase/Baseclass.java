package com.testbase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Baseclass {
	//Property file Load
	 
	String path=".\\Resources\\application.properties";	
	public static Properties prop;	
	public WebDriver driver;
	public String Expected="Bad credentials";
	public Baseclass() throws IOException
	{		
		prop=new Properties();		
		FileInputStream file=new FileInputStream(path);
		prop.load(file);
	}
	
	//Driver Initialization
	
	public void init()
	{
		String desc = "Open Browser and Enter URL";
		String browser= prop.getProperty("BROWSER_NAME");
		
		switch(browser)
		{
			case "Chrome":
			{
				driver=new ChromeDriver();
				break;
			}
			case "Firefox":
			{
			driver=new FirefoxDriver();
				break;
			}
			case "default":
			{
				break;
			}
		}
		}			
					
	//Launching the URL		
									
		public void launch()
			{
						
				driver.get(prop.getProperty("URL"));
				
			}
//Window Maximize
			public void windowmximize()
			{
				driver.manage().window().maximize();
			}
//wait
			public void waittime(int element)
			{
				driver.manage().timeouts().implicitlyWait(element,TimeUnit.SECONDS);
				
			}
			}
			
			
		
				
				
				



	