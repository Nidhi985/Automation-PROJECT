package com.utilities;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.testbase.Baseclass;



public class Reusablecomponents extends Baseclass {


public Reusablecomponents() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
//click and wait untill element is available
public void clickandwait(WebElement element,long waitinseconds)
{
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(waitinseconds));
	WebElement elements;
	elements=wait.until(ExpectedConditions.elementToBeClickable(element));
	elements.click();
	}

//send keys
public void entertext(WebElement webElement,String text)
{
	//webElement.click();
	webElement.sendKeys(text);
}
//alert
public void acceptallert()
{
	driver.switchTo().alert().accept();
}
public void dismissallert()
{
	driver.switchTo().alert().dismiss();
}
//To get the title of the page
public String gettitle()
{
	return driver.getTitle();
	
}
public String getText(WebElement element)
{
	return element.getText();
	
}

}

